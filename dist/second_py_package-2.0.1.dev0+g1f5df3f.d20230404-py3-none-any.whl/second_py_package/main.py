def print_text():
    print('This version 2.0.0')