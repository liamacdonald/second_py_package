def print_text():
    print('This version 0.0.1')