def print_text():
    print('This version 1.1.8')